SET timezone TO 'Asia/Kolkata';

INSERT INTO customer(full_name,email,phone,date_of_birth,pan) VALUES
('Priya Sharma','priya.sharma@example.com','9876500001','1995-04-12','ABCPS1234K'),
('Rahul Verma','rahul.verma@example.com','9876500002','1992-08-21','AKQPV5678L'),
('Ananya Iyer','ananya.iyer@example.com','9876500003','1994-11-09','ANANY1234P');

INSERT INTO account(account_number,customer_id,account_type,balance,status,opened_at,updated_at) VALUES
('501000000001',1,'SAVINGS',55000.00,'ACTIVE','2026-09-01 10:00:00+05:30','2026-09-28 12:10:00+05:30'),
('501000000002',2,'SAVINGS',26500.00,'ACTIVE','2026-09-01 10:05:00+05:30','2026-09-28 12:10:00+05:30'),
('501000000003',2,'CURRENT',97000.00,'ACTIVE','2026-09-05 09:15:00+05:30','2026-09-15 14:00:00+05:30'),
('501000000004',3,'SAVINGS',11500.00,'ACTIVE','2026-09-05 09:15:00+05:30','2026-09-28 12:10:00+05:30'),
('501000000005',3,'CURRENT',5000.00,'FROZEN','2026-09-05 09:20:00+05:30','2026-09-05 09:20:00+05:30');

-- Seed ledger: the statement for ...001 exactly matches the case study.
INSERT INTO account_transaction(account_id,transfer_id,txn_type,amount,balance_after,description,txn_time) VALUES
(1,NULL,'CREDIT',50000.00,50000.00,'Initial deposit','2026-09-01 10:00:00+05:30'),
(2,NULL,'CREDIT',26500.00,26500.00,'Initial deposit','2026-09-01 10:05:00+05:30'),
(3,NULL,'CREDIT',97000.00,97000.00,'Initial deposit','2026-09-05 09:15:00+05:30'),
(4,NULL,'CREDIT',11500.00,11500.00,'Initial deposit','2026-09-05 09:15:00+05:30'),
(5,NULL,'CREDIT',5000.00,5000.00,'Initial deposit','2026-09-05 09:20:00+05:30');

-- Three transfers touch Priya and reproduce the published September statement.
-- A fourth seed transfer is included between Rahul's accounts so the seed has four transfers as specified.
INSERT INTO fund_transfer(reference_no,idempotency_key,from_account_id,to_account_id,amount,remarks,created_at)
VALUES
('TRF20260910000001','seed-0001',1,2,5000.00,'Rent share','2026-09-10 09:30:00+05:30'),
('TRF20260915000002','seed-0002',3,1,12000.00,'Invoice 1043','2026-09-15 14:00:00+05:30'),
('TRF20260920000003','seed-0003',2,3,3000.00,'Internal sweep','2026-09-20 10:00:00+05:30'),
('TRF20260928000004','seed-0004',1,4,2000.00,'Birthday gift','2026-09-28 12:10:00+05:30');

INSERT INTO account_transaction(account_id,transfer_id,txn_type,amount,balance_after,description,txn_time)
SELECT 1,transfer_id,'DEBIT',5000.00,45000.00,'Transfer to 501000000002 - Rent share',created_at FROM fund_transfer WHERE idempotency_key='seed-0001'
UNION ALL
SELECT 2,transfer_id,'CREDIT',5000.00,31500.00,'Transfer from 501000000001 - Rent share',created_at FROM fund_transfer WHERE idempotency_key='seed-0001'
UNION ALL
SELECT 3,transfer_id,'DEBIT',12000.00,85000.00,'Transfer to 501000000001 - Invoice 1043',created_at FROM fund_transfer WHERE idempotency_key='seed-0002'
UNION ALL
SELECT 1,transfer_id,'CREDIT',12000.00,57000.00,'Transfer from 501000000003 - Invoice 1043',created_at FROM fund_transfer WHERE idempotency_key='seed-0002'
UNION ALL
SELECT 2,transfer_id,'DEBIT',3000.00,28500.00,'Transfer to 501000000003 - Internal sweep',created_at FROM fund_transfer WHERE idempotency_key='seed-0003'
UNION ALL
SELECT 3,transfer_id,'CREDIT',3000.00,88000.00,'Transfer from 501000000002 - Internal sweep',created_at FROM fund_transfer WHERE idempotency_key='seed-0003'
UNION ALL
SELECT 1,transfer_id,'DEBIT',2000.00,55000.00,'Transfer to 501000000004 - Birthday gift',created_at FROM fund_transfer WHERE idempotency_key='seed-0004'
UNION ALL
SELECT 4,transfer_id,'CREDIT',2000.00,17500.00,'Transfer from 501000000001 - Birthday gift',created_at FROM fund_transfer WHERE idempotency_key='seed-0004';

-- Correct account balances after the seed ledger above.
UPDATE account SET balance=55000.00, updated_at='2026-09-28 12:10:00+05:30' WHERE account_number='501000000001';
UPDATE account SET balance=28500.00, updated_at='2026-09-20 10:00:00+05:30' WHERE account_number='501000000002';
UPDATE account SET balance=88000.00, updated_at='2026-09-20 10:00:00+05:30' WHERE account_number='501000000003';
UPDATE account SET balance=13500.00, updated_at='2026-09-28 12:10:00+05:30' WHERE account_number='501000000004';

SELECT setval(pg_get_serial_sequence('customer','customer_id'), 3, true);
SELECT setval('account_account_id_seq', 5, true);
SELECT setval('account_number_seq', 5, true);
SELECT setval(pg_get_serial_sequence('account_transaction','txn_id'), (SELECT max(txn_id) FROM account_transaction), true);
SELECT setval('transfer_ref_seq', 4, true);
