CREATE EXTENSION IF NOT EXISTS pgcrypto;
ALTER DATABASE bankdb SET timezone TO 'Asia/Kolkata';
SET timezone TO 'Asia/Kolkata';

CREATE SEQUENCE account_number_seq START 1;
CREATE SEQUENCE transfer_ref_seq START 1;

CREATE TABLE customer (
  customer_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(10) NOT NULL,
  date_of_birth DATE NOT NULL,
  pan CHAR(10) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_customer_pan UNIQUE (pan),
  CONSTRAINT uq_customer_email UNIQUE (email),
  CONSTRAINT uq_customer_phone UNIQUE (phone),
  CONSTRAINT ck_customer_pan CHECK (pan ~ '^[A-Z]{5}[0-9]{4}[A-Z]$'),
  CONSTRAINT ck_customer_phone CHECK (phone ~ '^[6-9][0-9]{9}$'),
  CONSTRAINT ck_customer_email CHECK (email = lower(email))
);

CREATE TABLE account (
  account_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  account_number VARCHAR(12) NOT NULL DEFAULT ('5010' || lpad(nextval('account_number_seq')::text, 8, '0')),
  customer_id BIGINT NOT NULL REFERENCES customer(customer_id),
  account_type VARCHAR(10) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  balance NUMERIC(15,2) NOT NULL DEFAULT 0,
  status VARCHAR(10) NOT NULL DEFAULT 'ACTIVE',
  version INTEGER NOT NULL DEFAULT 0,
  opened_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_account_number UNIQUE (account_number),
  CONSTRAINT uq_account_customer_type UNIQUE (customer_id, account_type),
  CONSTRAINT ck_account_type CHECK (account_type IN ('SAVINGS','CURRENT')),
  CONSTRAINT ck_account_currency CHECK (currency = 'INR'),
  CONSTRAINT ck_account_status CHECK (status IN ('ACTIVE','FROZEN','CLOSED')),
  CONSTRAINT ck_account_balance CHECK (balance >= 0)
);

CREATE TABLE fund_transfer (
  transfer_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_no VARCHAR(20) NOT NULL DEFAULT ('TRF' || to_char(now(),'YYYYMMDD') || lpad(nextval('transfer_ref_seq')::text,6,'0')),
  idempotency_key VARCHAR(64) NOT NULL,
  from_account_id BIGINT NOT NULL REFERENCES account(account_id),
  to_account_id BIGINT NOT NULL REFERENCES account(account_id),
  amount NUMERIC(15,2) NOT NULL,
  remarks VARCHAR(100),
  status VARCHAR(10) NOT NULL DEFAULT 'COMPLETED',
  failure_reason VARCHAR(40),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT uq_transfer_reference UNIQUE(reference_no),
  CONSTRAINT uq_transfer_idempotency UNIQUE(idempotency_key),
  CONSTRAINT ck_transfer_accounts CHECK(from_account_id <> to_account_id),
  CONSTRAINT ck_transfer_amount CHECK(amount > 0),
  CONSTRAINT ck_transfer_status CHECK(status IN ('COMPLETED','FAILED')),
  CONSTRAINT ck_transfer_failure CHECK((status='FAILED') = (failure_reason IS NOT NULL))
);
CREATE INDEX ix_transfer_from_created ON fund_transfer(from_account_id, created_at);

CREATE TABLE account_transaction (
  txn_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  account_id BIGINT NOT NULL REFERENCES account(account_id),
  transfer_id UUID REFERENCES fund_transfer(transfer_id),
  txn_type VARCHAR(6) NOT NULL,
  amount NUMERIC(15,2) NOT NULL,
  balance_after NUMERIC(15,2) NOT NULL,
  description VARCHAR(140) NOT NULL,
  txn_time TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT ck_txn_type CHECK(txn_type IN ('CREDIT','DEBIT')),
  CONSTRAINT ck_txn_amount CHECK(amount > 0),
  CONSTRAINT ck_txn_balance CHECK(balance_after >= 0),
  CONSTRAINT uq_txn_transfer_leg UNIQUE(transfer_id, txn_type)
);
CREATE INDEX ix_txn_account_time ON account_transaction(account_id, txn_time DESC, txn_id DESC);

CREATE TABLE notification_log (
  event_id UUID NOT NULL,
  account_number VARCHAR(12) NOT NULL,
  event_type VARCHAR(40) NOT NULL,
  channel VARCHAR(10) NOT NULL DEFAULT 'SMS',
  message VARCHAR(300) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT pk_notification_log PRIMARY KEY(event_id, account_number)
);

CREATE ROLE bank_app LOGIN PASSWORD 'bank_app_pwd';
GRANT CONNECT ON DATABASE bankdb TO bank_app;
GRANT USAGE ON SCHEMA public TO bank_app;
GRANT SELECT, INSERT, UPDATE ON customer, account, fund_transfer TO bank_app;
GRANT SELECT, INSERT ON account_transaction, notification_log TO bank_app;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO bank_app;
REVOKE UPDATE, DELETE ON account_transaction FROM bank_app;
REVOKE DELETE ON customer, account, fund_transfer, notification_log FROM bank_app;
