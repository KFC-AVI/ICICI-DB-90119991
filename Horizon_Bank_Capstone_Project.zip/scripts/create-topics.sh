#!/bin/sh
set -eu
docker exec bank-kafka kafka-topics.sh --bootstrap-server localhost:9092 --create --if-not-exists --topic bank.account.opened.v1 --partitions 3 --replication-factor 1
docker exec bank-kafka kafka-topics.sh --bootstrap-server localhost:9092 --create --if-not-exists --topic bank.transfer.completed.v1 --partitions 3 --replication-factor 1
docker exec bank-kafka kafka-topics.sh --bootstrap-server localhost:9092 --create --if-not-exists --topic bank.transfer.failed.v1 --partitions 3 --replication-factor 1
docker exec bank-kafka kafka-topics.sh --bootstrap-server localhost:9092 --list
