#!/bin/bash
set -euo pipefail
BASE_URL="${BASE_URL:-http://localhost:8080}"
FROM="${FROM:-501000000004}"
TO="${TO:-501000000002}"
AMOUNT="${AMOUNT:-1000.00}"
TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT
for i in $(seq 1 20); do
  (
    code=$(curl -sS -o /tmp/bank_resp_$i.json -w '%{http_code}' -X POST "$BASE_URL/api/v1/transfers" \
      -H 'Content-Type: application/json' -H "Idempotency-Key: concurrency-$i" \
      -d "{\"fromAccountNumber\":\"$FROM\",\"toAccountNumber\":\"$TO\",\"amount\":\"$AMOUNT\"}")
    echo "$code" >> "$TMP"
  ) &
done
wait
printf '201 count: '; grep -c '^201$' "$TMP" || true
printf '422 count: '; grep -c '^422$' "$TMP" || true
printf 'all status codes:\n'; sort "$TMP" | uniq -c
printf '\nExpected for TC-20 with ...004 starting at 13,500: 13 successful + 7 insufficient.\n'
