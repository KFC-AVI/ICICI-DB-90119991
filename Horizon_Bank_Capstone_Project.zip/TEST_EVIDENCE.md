# Test Evidence Sheet — Horizon Bank

Run on a fresh stack. Record actual outputs/screenshots rather than claiming a pass before execution.

| ID | Scenario | Expected | Actual | Pass? | Evidence |
|---|---|---|---|---|---|
| TC-01 | Open new SAVINGS | 201, account ...006, ledger, AccountOpened | | | |
| TC-02 | Deposit below minimum | 400 VALIDATION_ERROR | | | |
| TC-03 | Invalid PAN | 400 VALIDATION_ERROR | | | |
| TC-04 | Under 18 | 400 VALIDATION_ERROR | | | |
| TC-05 | Duplicate SAVINGS | 409 DUPLICATE_ACCOUNT_TYPE | | | |
| TC-06 | Existing customer CURRENT | 201, same customer | | | |
| TC-07 | Customer conflict | 409 CUSTOMER_CONFLICT | | | |
| TC-08 | Account cache | MISS then HIT | | | |
| TC-09 | Unknown account | 404 | | | |
| TC-10 | Successful transfer | 201, 2 ledger rows | | | |
| TC-11 | Idempotent replay | same body + replay header | | | |
| TC-12 | Missing key | 400 MISSING_IDEMPOTENCY_KEY | | | |
| TC-13 | Insufficient funds | 422 | | | |
| TC-14 | Same account | 422 SAME_ACCOUNT_TRANSFER | | | |
| TC-15 | Frozen receiver | 422 ACCOUNT_NOT_ACTIVE | | | |
| TC-16 | Bad amounts | 400 | | | |
| TC-17 | Over per-transfer limit | 400 | | | |
| TC-18 | Daily limit | fourth transfer 422 | | | |
| TC-19 | Unknown receiver | 404 | | | |
| TC-20 | 20 concurrent transfers | 13 success / 7 rejected for seed ...004 | | | |
| TC-21 | September statement | opening 0, closing 55000, 62000 credits, 7000 debits, 4 rows | | | |
| TC-22 | Current-month statement | current balance and TC-10 | | | |
| TC-23 | Reversed dates | 400 | | | |
| TC-24 | >90 days | 400 | | | |
| TC-25 | Paging | 3 rows then 1 row | | | |
| TC-26 | Statement cache | HIT then MISS after transfer | | | |
| TC-27 | Kafka events | AccountOpened + TransferCompleted, 3 notification rows | | | |
| TC-28 | Kafka replay | notification count unchanged | | | |
| TC-29 | Redis down | API remains correct; replay safe via DB key | | | |
| TC-30 | Kafka down | transfer still succeeds; publish error logged | | | |

## Reconciliation

Run `docker exec bank-postgres psql -U bank_app -d bankdb -f /sql/04_reconciliation.sql`.

**Expected:** R1, R2 and R3 each return zero rows.
