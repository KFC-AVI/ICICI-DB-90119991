import json
import logging
from confluent_kafka import Consumer
from psycopg_pool import ConnectionPool
from .config import settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log=logging.getLogger("notification-service")
pool=ConnectionPool(settings.database_url, min_size=1, max_size=4, kwargs={"row_factory": __import__('psycopg').rows.dict_row}, open=True)

consumer=Consumer({
    "bootstrap.servers": settings.kafka_bootstrap_servers,
    "group.id": settings.kafka_group_id,
    "client.id": settings.kafka_client_id,
    "auto.offset.reset": "earliest",
    "enable.auto.commit": False,
})

def mask(no): return "XX" + no[-6:]

def write_notifications(event):
    event_id=event["eventId"]
    typ=event["eventType"]
    data=event["data"]
    if typ=="AccountOpened":
        account=data["accountNumber"]
        message=f"Account {mask(account)} opened with initial deposit Rs {data['balance']}."
        rows=[(event_id,account,typ,message)]
    elif typ=="TransferCompleted":
        frm=data["fromAccountNumber"]; to=data["toAccountNumber"]; ref=data["referenceNo"]; amount=data["amount"]
        rows=[
          (event_id,frm,typ,f"Rs {amount} debited from A/c {mask(frm)} to A/c {mask(to)}. Ref {ref}. Avl bal Rs {data['fromBalanceAfter']}"),
          (event_id,to,typ,f"Rs {amount} credited to A/c {mask(to)} from A/c {mask(frm)}. Ref {ref}. Avl bal Rs {data['toBalanceAfter']}"),
        ]
    else:
        return
    with pool.connection() as conn:
        with conn.transaction():
            conn.executemany("""INSERT INTO notification_log(event_id,account_number,event_type,message) VALUES(%s,%s,%s,%s) ON CONFLICT(event_id,account_number) DO NOTHING""",rows)

def main():
    topics=["bank.account.opened.v1","bank.transfer.completed.v1","bank.transfer.failed.v1"]
    consumer.subscribe(topics)
    log.info("notification-service listening on %s", topics)
    try:
        while True:
            msg=consumer.poll(1.0)
            if msg is None: continue
            if msg.error():
                log.error("Kafka error: %s",msg.error()); continue
            try:
                event=json.loads(msg.value().decode())
                write_notifications(event)
                consumer.commit(message=msg, asynchronous=False)
            except Exception:
                log.exception("event processing failed; offset not committed")
    finally:
        consumer.close(); pool.close()

if __name__=="__main__": main()
