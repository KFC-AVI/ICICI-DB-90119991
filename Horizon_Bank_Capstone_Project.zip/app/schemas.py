from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pydantic import BaseModel, ConfigDict, Field, field_validator
import re

PAN_RE = re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")
PHONE_RE = re.compile(r"^[6-9][0-9]{9}$")
ACCOUNT_RE = re.compile(r"^[0-9]{12}$")
IDEM_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")

class CustomerIn(BaseModel):
    fullName: str = Field(min_length=3, max_length=100)
    email: str = Field(max_length=150)
    phone: str
    dateOfBirth: date
    pan: str
    @field_validator("email", mode="before")
    @classmethod
    def email_lower(cls, v): return str(v).strip().lower()
    @field_validator("phone")
    @classmethod
    def phone_valid(cls, v):
        if not PHONE_RE.fullmatch(v): raise ValueError("must be a 10-digit Indian mobile number")
        return v
    @field_validator("pan", mode="before")
    @classmethod
    def pan_upper(cls, v):
        v = str(v).upper()
        if not PAN_RE.fullmatch(v): raise ValueError("must match AAAAA9999A")
        return v

class OpenAccountIn(BaseModel):
    customer: CustomerIn
    accountType: str
    initialDeposit: Decimal
    @field_validator("accountType", mode="before")
    @classmethod
    def account_type(cls, v):
        v = str(v).upper()
        if v not in {"SAVINGS", "CURRENT"}: raise ValueError("must be SAVINGS or CURRENT")
        return v
    @field_validator("initialDeposit", mode="before")
    @classmethod
    def amount(cls, v):
        try: d=Decimal(str(v))
        except InvalidOperation: raise ValueError("must be a decimal amount")
        if d.as_tuple().exponent < -2: raise ValueError("maximum 2 decimal places")
        return d

class TransferIn(BaseModel):
    fromAccountNumber: str
    toAccountNumber: str
    amount: Decimal
    remarks: str | None = Field(default=None, max_length=100)
    @field_validator("fromAccountNumber", "toAccountNumber")
    @classmethod
    def account_no(cls, v):
        if not ACCOUNT_RE.fullmatch(v): raise ValueError("must be 12 digits")
        return v
    @field_validator("amount", mode="before")
    @classmethod
    def amount(cls, v):
        try: d=Decimal(str(v))
        except InvalidOperation: raise ValueError("must be a decimal amount")
        if d.as_tuple().exponent < -2: raise ValueError("maximum 2 decimal places")
        return d

class ErrorOut(BaseModel):
    type: str = "about:blank"
    title: str
    status: int
    detail: str
    errorCode: str
    correlationId: str
    errors: list = []
