import json
import uuid
from datetime import datetime, timezone
from confluent_kafka import Producer
from .config import settings

producer = Producer({
    "bootstrap.servers": settings.kafka_bootstrap_servers,
    "client.id": settings.kafka_client_id,
    "acks": "all",
    "enable.idempotence": True,
    "max.block.ms": 5000,
    "delivery.timeout.ms": 10000,
})

def envelope(event_type, correlation_id, data):
    return {
        "eventId": str(uuid.uuid4()),
        "eventType": event_type,
        "occurredAt": datetime.now(timezone.utc).astimezone().isoformat(),
        "correlationId": correlation_id,
        "data": data,
    }

def publish(topic, key, event):
    producer.produce(topic, key=key, value=json.dumps(event, default=str))
    producer.poll(0)
    producer.flush(5)
