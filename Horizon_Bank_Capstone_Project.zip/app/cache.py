import json
import logging
import redis
from .config import settings

log = logging.getLogger(__name__)
client = redis.Redis.from_url(settings.redis_url, decode_responses=True, socket_connect_timeout=0.5, socket_timeout=0.5)

def account_key(no): return f"bank:account:{no}"
def stmt_ver_key(no): return f"bank:stmt-ver:{no}"
def stmt_key(no, ver, from_date, to_date, page, size): return f"bank:stmt:{no}:v{ver}:{from_date}:{to_date}:{page}:{size}"
def idem_key(key): return f"bank:idem:{key}"

def get_account(no):
    try:
        return client.hgetall(account_key(no))
    except redis.RedisError as e:
        log.warning("redis read failed: %s", e)
        return {}

def set_account(no, value):
    try:
        client.hset(account_key(no), mapping=value)
        client.expire(account_key(no), settings.account_cache_ttl)
    except redis.RedisError as e:
        log.warning("redis write failed: %s", e)

def invalidate_accounts(*numbers):
    try:
        pipe = client.pipeline()
        for no in numbers:
            pipe.delete(account_key(no))
            pipe.incr(stmt_ver_key(no))
        pipe.execute()
    except redis.RedisError as e:
        log.warning("redis invalidation failed: %s", e)

def get_statement(no, from_date, to_date, page, size):
    try:
        ver = int(client.get(stmt_ver_key(no)) or 0)
        key = stmt_key(no, ver, from_date, to_date, page, size)
        raw = client.get(key)
        return (json.loads(raw), True) if raw else (None, False)
    except redis.RedisError as e:
        log.warning("redis statement read failed: %s", e)
        return None, False

def set_statement(no, from_date, to_date, page, size, body):
    try:
        ver = int(client.get(stmt_ver_key(no)) or 0)
        key = stmt_key(no, ver, from_date, to_date, page, size)
        client.set(key, json.dumps(body, separators=(",", ":")), ex=settings.statement_cache_ttl)
    except redis.RedisError as e:
        log.warning("redis statement write failed: %s", e)

def claim_idempotency(key):
    try:
        return client.set(idem_key(key), "PENDING", nx=True, ex=settings.idempotency_ttl)
    except redis.RedisError as e:
        log.warning("redis idempotency unavailable: %s", e)
        return None

def get_idempotency(key):
    try:
        return client.get(idem_key(key))
    except redis.RedisError:
        return None

def store_idempotency(key, payload):
    try:
        client.set(idem_key(key), json.dumps(payload, separators=(",", ":")), xx=True, ex=settings.idempotency_ttl)
    except redis.RedisError as e:
        log.warning("redis idempotency store failed: %s", e)

def clear_idempotency(key):
    try:
        client.delete(idem_key(key))
    except redis.RedisError:
        pass
