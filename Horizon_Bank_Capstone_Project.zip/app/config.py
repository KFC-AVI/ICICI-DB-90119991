from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    port: int = 8080
    database_url: str = "postgresql://bank_app:bank_app_pwd@localhost:5432/bankdb"
    redis_url: str = "redis://localhost:6379/0"
    kafka_bootstrap_servers: str = "localhost:9092"
    kafka_client_id: str = "bank-account-service"
    kafka_group_id: str = "notification-service"
    app_zone: str = "Asia/Kolkata"
    account_cache_ttl: int = 600
    statement_cache_ttl: int = 300
    idempotency_ttl: int = 86400
    daily_transfer_limit: str = "500000.00"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
