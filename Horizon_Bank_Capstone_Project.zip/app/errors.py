class ApiError(Exception):
    def __init__(self, status: int, error_code: str, detail: str | None = None, errors=None, headers=None):
        self.status = status
        self.error_code = error_code
        self.detail = detail or error_code
        self.errors = errors or []
        self.headers = headers or {}
        super().__init__(self.detail)
