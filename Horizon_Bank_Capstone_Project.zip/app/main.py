import json
import logging
import re
import uuid
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Request, Response, Header, Query
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from .config import settings
from .db import pool, open_pool, close_pool
from .errors import ApiError
from . import cache
from .schemas import OpenAccountIn, TransferIn
from .events import producer, publish, envelope

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)
IST = ZoneInfo(settings.app_zone)
DAILY_LIMIT = Decimal(settings.daily_transfer_limit)

app = FastAPI(title="Horizon Bank Account System", version="1.0.0")

@app.on_event("startup")
def startup():
    open_pool()

@app.on_event("shutdown")
def shutdown():
    try: producer.flush(5)
    finally: close_pool()

def correlation(request: Request) -> str:
    return request.headers.get("X-Correlation-Id") or str(uuid.uuid4())

def problem(exc: ApiError, corr: str):
    body = {
        "type": "about:blank", "title": exc.error_code, "status": exc.status,
        "detail": exc.detail, "errorCode": exc.error_code, "correlationId": corr,
        "errors": exc.errors,
    }
    headers = {"Content-Type": "application/problem+json", "X-Correlation-Id": corr, **exc.headers}
    return JSONResponse(status_code=exc.status, content=body, headers=headers, media_type="application/problem+json")

@app.middleware("http")
async def correlation_middleware(request: Request, call_next):
    corr = correlation(request)
    request.state.correlation_id = corr
    try:
        response = await call_next(request)
    except ApiError as e:
        response = problem(e, corr)
    except Exception:
        log.exception("unhandled error correlation=%s", corr)
        response = problem(ApiError(500, "INTERNAL_ERROR", "Internal server error"), corr)
    response.headers["X-Correlation-Id"] = corr
    return response

@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    errors=[]
    for e in exc.errors():
        loc=".".join(str(x) for x in e.get("loc", []) if x != "body")
        errors.append({"field": loc, "message": e.get("msg", "Invalid value")})
    return problem(ApiError(400, "VALIDATION_ERROR", "Request validation failed", errors), request.state.correlation_id)

@app.get("/health")
@app.get("/actuator/health")
def health():
    db_ok=redis_ok=kafka_ok=False
    try:
        with pool.connection() as conn:
            conn.execute("SELECT 1").fetchone(); db_ok=True
    except Exception: pass
    try:
        cache.client.ping(); redis_ok=True
    except Exception: pass
    try:
        producer.list_topics(timeout=1); kafka_ok=True
    except Exception: pass
    status = "UP" if db_ok and redis_ok and kafka_ok else "DEGRADED"
    return {"status": status, "database": "UP" if db_ok else "DOWN", "redis": "UP" if redis_ok else "DOWN", "kafka": "UP" if kafka_ok else "DOWN"}


def age_on(dob: date, on: date) -> int:
    return on.year - dob.year - ((on.month, on.day) < (dob.month, dob.day))

def decimal_str(v) -> str:
    return format(Decimal(v).quantize(Decimal("0.01")), "f")

def iso(v):
    return v.astimezone(IST).isoformat() if hasattr(v, "astimezone") else v

@app.post("/api/v1/accounts", status_code=201)
def open_account(req: OpenAccountIn, request: Request, response: Response):
    corr=request.state.correlation_id
    today=datetime.now(IST).date()
    errors=[]
    if age_on(req.customer.dateOfBirth, today) < 18:
        errors.append({"field":"customer.dateOfBirth","message":"customer must be at least 18 years old"})
    minimum=Decimal("1000.00") if req.accountType=="SAVINGS" else Decimal("5000.00")
    if req.initialDeposit < minimum or req.initialDeposit > Decimal("1000000.00"):
        errors.append({"field":"initialDeposit","message":f"must be between {minimum} and 1000000.00"})
    if errors: raise ApiError(400,"VALIDATION_ERROR","Request validation failed",errors)

    customer_name = req.customer.fullName
    with pool.connection() as conn:
        try:
            with conn.transaction():
                existing=conn.execute("SELECT * FROM customer WHERE pan=%s FOR UPDATE",(req.customer.pan,)).fetchone()
                new_customer=False
                if existing:
                    customer_id=existing["customer_id"]
                else:
                    conflict=conn.execute("SELECT pan FROM customer WHERE email=%s OR phone=%s LIMIT 1",(req.customer.email,req.customer.phone)).fetchone()
                    if conflict: raise ApiError(409,"CUSTOMER_CONFLICT","The e-mail or phone belongs to another customer")
                    row=conn.execute("""INSERT INTO customer(full_name,email,phone,date_of_birth,pan) VALUES(%s,%s,%s,%s,%s) RETURNING customer_id""",
                        (req.customer.fullName,req.customer.email,req.customer.phone,req.customer.dateOfBirth,req.customer.pan)).fetchone()
                    customer_id=row["customer_id"]; new_customer=True
                    customer_name=req.customer.fullName
                try:
                    acc=conn.execute("""INSERT INTO account(customer_id,account_type,balance) VALUES(%s,%s,%s)
                    RETURNING account_number,customer_id,account_type,currency,balance,status,opened_at""",(customer_id,req.accountType,req.initialDeposit)).fetchone()
                except Exception as e:
                    if getattr(e,"diag",None) and e.diag.constraint_name=="uq_account_customer_type":
                        raise ApiError(409,"DUPLICATE_ACCOUNT_TYPE","Customer already has an account of this type")
                    raise
                conn.execute("""INSERT INTO account_transaction(account_id,transfer_id,txn_type,amount,balance_after,description)
                    SELECT account_id,NULL,'CREDIT',%s,balance,'Initial deposit' FROM account WHERE account_number=%s""",(req.initialDeposit,acc["account_number"]))
        except ApiError: raise
        except Exception as e:
            if getattr(e,"diag",None) and e.diag.constraint_name in {"uq_customer_email","uq_customer_phone"}:
                raise ApiError(409,"CUSTOMER_CONFLICT","The e-mail or phone belongs to another customer")
            raise

    if not new_customer:
        customer_name = existing["full_name"]
    body={"accountNumber":acc["account_number"],"customerId":customer_id,"customerName":customer_name,
          "newCustomer":new_customer,"accountType":acc["account_type"],"currency":acc["currency"],"balance":decimal_str(acc["balance"]),"status":acc["status"],"openedAt":iso(acc["opened_at"])}
    response.headers["Location"]=f"/api/v1/accounts/{acc['account_number']}"
    try:
        event=envelope("AccountOpened",corr,body)
        publish("bank.account.opened.v1",acc["account_number"],event)
    except Exception as e: log.error("Kafka publish failed for AccountOpened: %s",e)
    return body

@app.get("/api/v1/accounts/{account_number}")
def get_account(account_number: str, request: Request, response: Response):
    corr=request.state.correlation_id
    if not re.fullmatch(r"\d{12}",account_number): raise ApiError(400,"VALIDATION_ERROR","accountNumber must be 12 digits")
    cached=cache.get_account(account_number)
    if cached:
        response.headers["X-Cache"]="HIT"
        return {"accountNumber":cached["accountNumber"],"customerName":cached["customerName"],"accountType":cached["accountType"],"currency":cached["currency"],"balance":cached["balance"],"status":cached["status"],"openedAt":cached["openedAt"]}
    with pool.connection() as conn:
        row=conn.execute("""SELECT a.account_number,c.full_name,a.account_type,a.currency,a.balance,a.status,a.opened_at
        FROM account a JOIN customer c USING(customer_id) WHERE a.account_number=%s""",(account_number,)).fetchone()
    if not row: raise ApiError(404,"ACCOUNT_NOT_FOUND",f"Account {account_number} not found")
    body={"accountNumber":row["account_number"],"customerName":row["full_name"],"accountType":row["account_type"],"currency":row["currency"],"balance":decimal_str(row["balance"]),"status":row["status"],"openedAt":iso(row["opened_at"])}
    cache.set_account(account_number,body)
    response.headers["X-Cache"]="MISS"
    return body


def validate_transfer(req: TransferIn):
    errors=[]
    if req.fromAccountNumber==req.toAccountNumber: raise ApiError(422,"SAME_ACCOUNT_TRANSFER","Sender and receiver accounts must differ")
    if req.amount < Decimal("1.00") or req.amount > Decimal("200000.00"):
        errors.append({"field":"amount","message":"must be between 1.00 and 200000.00"})
    if errors: raise ApiError(400,"VALIDATION_ERROR","Request validation failed",errors)

@app.post("/api/v1/transfers",status_code=201)
def transfer(req: TransferIn, request: Request, response: Response, idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
    corr=request.state.correlation_id
    if not idempotency_key or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}",idempotency_key): raise ApiError(400,"MISSING_IDEMPOTENCY_KEY","Idempotency-Key header is required and must be 1-64 alphanumeric characters, - or _")
    validate_transfer(req)
    claim=cache.claim_idempotency(idempotency_key)
    if claim is False:
        stored=cache.get_idempotency(idempotency_key)
        if stored and stored!="PENDING":
            payload=json.loads(stored); response.headers["Idempotent-Replayed"]="true"; response.status_code=payload["httpStatus"]; return payload["body"]
        raise ApiError(409,"REQUEST_IN_PROGRESS","The same idempotency key is still being processed")

    try:
        with pool.connection() as conn:
            try:
                with conn.transaction():
                    conn.execute("SET LOCAL lock_timeout='3s'")
                    rows=conn.execute("""SELECT account_id,account_number,balance,status FROM account
                        WHERE account_number IN (%s,%s) ORDER BY account_id FOR UPDATE""",(req.fromAccountNumber,req.toAccountNumber)).fetchall()
                    by_no={r["account_number"]:r for r in rows}
                    if req.fromAccountNumber not in by_no: raise ApiError(404,"ACCOUNT_NOT_FOUND",f"Account {req.fromAccountNumber} not found")
                    if req.toAccountNumber not in by_no: raise ApiError(404,"ACCOUNT_NOT_FOUND",f"Account {req.toAccountNumber} not found")
                    src,dst=by_no[req.fromAccountNumber],by_no[req.toAccountNumber]
                    if src["status"]!="ACTIVE" or dst["status"]!="ACTIVE": raise ApiError(422,"ACCOUNT_NOT_ACTIVE","Both accounts must be ACTIVE")
                    if src["balance"] < req.amount: raise ApiError(422,"INSUFFICIENT_FUNDS","Insufficient funds")
                    day_start=datetime.combine(datetime.now(IST).date(),time.min,tzinfo=IST)
                    sent=conn.execute("""SELECT COALESCE(SUM(amount),0) AS sent FROM fund_transfer
                        WHERE from_account_id=%s AND status='COMPLETED' AND created_at >= %s""",(src["account_id"],day_start)).fetchone()["sent"]
                    if sent + req.amount > DAILY_LIMIT: raise ApiError(422,"DAILY_LIMIT_EXCEEDED","Daily transfer limit exceeded")
                    try:
                        t=conn.execute("""INSERT INTO fund_transfer(idempotency_key,from_account_id,to_account_id,amount,remarks)
                            VALUES(%s,%s,%s,%s,%s) RETURNING transfer_id,reference_no,created_at""",(idempotency_key,src["account_id"],dst["account_id"],req.amount,req.remarks)).fetchone()
                    except Exception as e:
                        if getattr(e,"diag",None) and e.diag.constraint_name=="uq_transfer_idempotency":
                            existing=conn.execute("SELECT * FROM fund_transfer WHERE idempotency_key=%s",(idempotency_key,)).fetchone()
                            body=build_transfer_body(conn,existing)
                            raise ApiError(200,"IDEMPOTENT_REPLAY",json.dumps(body))
                        raise
                    from_bal=conn.execute("UPDATE account SET balance=balance-%s,updated_at=now() WHERE account_id=%s RETURNING balance",(req.amount,src["account_id"])).fetchone()["balance"]
                    to_bal=conn.execute("UPDATE account SET balance=balance+%s,updated_at=now() WHERE account_id=%s RETURNING balance",(req.amount,dst["account_id"])).fetchone()["balance"]
                    suffix=f" - {req.remarks}" if req.remarks else ""
                    conn.execute("""INSERT INTO account_transaction(account_id,transfer_id,txn_type,amount,balance_after,description)
                        VALUES(%s,%s,'DEBIT',%s,%s,%s),(%s,%s,'CREDIT',%s,%s,%s)""",
                        (src["account_id"],t["transfer_id"],req.amount,from_bal,f"Transfer to {req.toAccountNumber}{suffix}",dst["account_id"],t["transfer_id"],req.amount,to_bal,f"Transfer from {req.fromAccountNumber}{suffix}"))
                    body={"transferId":str(t["transfer_id"]),"referenceNo":t["reference_no"],"status":"COMPLETED","fromAccountNumber":req.fromAccountNumber,"toAccountNumber":req.toAccountNumber,"amount":decimal_str(req.amount),"currency":"INR","remarks":req.remarks,"fromBalanceAfter":decimal_str(from_bal),"toBalanceAfter":decimal_str(to_bal),"createdAt":iso(t["created_at"])}
            except ApiError as e:
                if e.error_code=="IDEMPOTENT_REPLAY":
                    body=json.loads(e.detail); cache.store_idempotency(idempotency_key,{"httpStatus":201,"body":body}); response.headers["Idempotent-Replayed"]="true"; return {k:v for k,v in body.items() if k!="toBalanceAfter"}
                raise
            except Exception as e:
                if getattr(e,"sqlstate",None) in {"55P03","40P01"}: raise ApiError(503,"SERVICE_BUSY","Database lock unavailable",headers={"Retry-After":"1"})
                raise
    except ApiError as e:
        payload={"httpStatus":e.status,"body":{"type":"about:blank","title":e.error_code,"status":e.status,"detail":e.detail,"errorCode":e.error_code,"correlationId":corr,"errors":e.errors}}
        cache.store_idempotency(idempotency_key,payload)
        raise
    except Exception:
        cache.clear_idempotency(idempotency_key)
        raise

    public_body={k:v for k,v in body.items() if k!="toBalanceAfter"}
    cache.invalidate_accounts(req.fromAccountNumber,req.toAccountNumber)
    cache.store_idempotency(idempotency_key,{"httpStatus":201,"body":public_body})
    response.headers["Location"]=f"/api/v1/transfers/{body['referenceNo']}"
    try:
        event_data=dict(body)
        event=envelope("TransferCompleted",corr,event_data)
        publish("bank.transfer.completed.v1",req.fromAccountNumber,event)
    except Exception as e: log.error("Kafka publish failed for transfer %s: %s",body["referenceNo"],e)
    return public_body


def build_transfer_body(conn, t):
    r=conn.execute("""SELECT ft.*,a1.account_number from_account_number,a2.account_number to_account_number
        FROM fund_transfer ft JOIN account a1 ON a1.account_id=ft.from_account_id JOIN account a2 ON a2.account_id=ft.to_account_id
        WHERE ft.transfer_id=%s""",(t["transfer_id"],)).fetchone()
    legs=conn.execute("SELECT account_id,balance_after FROM account_transaction WHERE transfer_id=%s",(t["transfer_id"],)).fetchall()
    fb=next((x["balance_after"] for x in legs if x["account_id"]==r["from_account_id"]),None)
    tb=next((x["balance_after"] for x in legs if x["account_id"]==r["to_account_id"]),None)
    return {"transferId":str(r["transfer_id"]),"referenceNo":r["reference_no"],"status":r["status"],"fromAccountNumber":r["from_account_number"],"toAccountNumber":r["to_account_number"],"amount":decimal_str(r["amount"]),"currency":"INR","remarks":r["remarks"],"fromBalanceAfter":decimal_str(fb) if fb is not None else None,"toBalanceAfter":decimal_str(tb) if tb is not None else None,"createdAt":iso(r["created_at"]) }

@app.get("/api/v1/transfers/{reference_no}")
def transfer_enquiry(reference_no: str, request: Request):
    with pool.connection() as conn:
        r=conn.execute("""SELECT ft.*,a1.account_number from_account_number,a2.account_number to_account_number
            FROM fund_transfer ft JOIN account a1 ON a1.account_id=ft.from_account_id JOIN account a2 ON a2.account_id=ft.to_account_id
            WHERE ft.reference_no=%s""",(reference_no,)).fetchone()
    if not r: raise ApiError(404,"TRANSFER_NOT_FOUND",f"Transfer {reference_no} not found")
    return {"transferId":str(r["transfer_id"]),"referenceNo":r["reference_no"],"status":r["status"],"fromAccountNumber":r["from_account_number"],"toAccountNumber":r["to_account_number"],"amount":decimal_str(r["amount"]),"currency":"INR","remarks":r["remarks"],"createdAt":iso(r["created_at"]) }

@app.get("/api/v1/accounts/{account_number}/statement")
def statement(account_number: str, request: Request, response: Response,
              fromDate: date | None = Query(default=None), toDate: date | None = Query(default=None), page: int = Query(default=0), size: int = Query(default=20)):
    corr=request.state.correlation_id
    if not re.fullmatch(r"\d{12}",account_number): raise ApiError(400,"VALIDATION_ERROR","accountNumber must be 12 digits")
    today=datetime.now(IST).date()
    from_d=fromDate or (today-timedelta(days=29)); to_d=toDate or today
    errs=[]
    if from_d>to_d: errs.append({"field":"fromDate","message":"must be on or before toDate"})
    if (to_d-from_d).days>89: errs.append({"field":"dateRange","message":"maximum range is 90 days"})
    if to_d>today: errs.append({"field":"toDate","message":"cannot be in the future"})
    if page<0: errs.append({"field":"page","message":"must be >= 0"})
    if size<1 or size>100: errs.append({"field":"size","message":"must be between 1 and 100"})
    if errs: raise ApiError(400,"VALIDATION_ERROR","Request validation failed",errs)
    cached,hit=cache.get_statement(account_number,str(from_d),str(to_d),page,size)
    if cached:
        response.headers["X-Cache"]="HIT"; return cached
    start=datetime.combine(from_d,time.min,tzinfo=IST); end=datetime.combine(to_d+timedelta(days=1),time.min,tzinfo=IST)
    with pool.connection() as conn:
        acc=conn.execute("SELECT a.account_number,c.full_name,a.currency FROM account a JOIN customer c USING(customer_id) WHERE a.account_number=%s",(account_number,)).fetchone()
        if not acc: raise ApiError(404,"ACCOUNT_NOT_FOUND",f"Account {account_number} not found")
        rows=conn.execute("""SELECT t.txn_id,t.txn_time,t.txn_type,t.amount,t.balance_after,t.description,ft.reference_no
            FROM account_transaction t LEFT JOIN fund_transfer ft ON ft.transfer_id=t.transfer_id
            WHERE t.account_id=(SELECT account_id FROM account WHERE account_number=%s) AND t.txn_time>=%s AND t.txn_time<%s
            ORDER BY t.txn_time DESC,t.txn_id DESC LIMIT %s OFFSET %s""",(account_number,start,end,size,page*size)).fetchall()
        meta=conn.execute("""SELECT count(*) total_elements,ceil(count(*)::numeric/%s) total_pages,
            COALESCE(sum(amount) FILTER(WHERE txn_type='CREDIT'),0) total_credits,
            COALESCE(sum(amount) FILTER(WHERE txn_type='DEBIT'),0) total_debits
            FROM account_transaction WHERE account_id=(SELECT account_id FROM account WHERE account_number=%s) AND txn_time>=%s AND txn_time<%s""",(size,account_number,start,end)).fetchone()
        bal=conn.execute("""SELECT COALESCE((SELECT balance_after FROM account_transaction WHERE account_id=(SELECT account_id FROM account WHERE account_number=%s) AND txn_time<%s ORDER BY txn_time DESC,txn_id DESC LIMIT 1),0) opening_balance,
            COALESCE((SELECT balance_after FROM account_transaction WHERE account_id=(SELECT account_id FROM account WHERE account_number=%s) AND txn_time<%s ORDER BY txn_time DESC,txn_id DESC LIMIT 1),0) closing_balance""",(account_number,start,account_number,end)).fetchone()
    body={"accountNumber":account_number,"customerName":acc["full_name"],"currency":acc["currency"],"fromDate":str(from_d),"toDate":str(to_d),"openingBalance":decimal_str(bal["opening_balance"]),"closingBalance":decimal_str(bal["closing_balance"]),"totalCredits":decimal_str(meta["total_credits"]),"totalDebits":decimal_str(meta["total_debits"]),"page":page,"size":size,"totalElements":int(meta["total_elements"]),"totalPages":int(meta["total_pages"]),"transactions":[{"txnId":r["txn_id"],"txnTime":iso(r["txn_time"]),"type":r["txn_type"],"amount":decimal_str(r["amount"]),"balanceAfter":decimal_str(r["balance_after"]),"description":r["description"],"referenceNo":r["reference_no"]} for r in rows]}
    cache.set_statement(account_number,str(from_d),str(to_d),page,size,body)
    response.headers["X-Cache"]="MISS"
    return body

@app.exception_handler(ApiError)
async def api_error_handler(request: Request, exc: ApiError):
    return problem(exc, getattr(request.state,"correlation_id",str(uuid.uuid4())))
