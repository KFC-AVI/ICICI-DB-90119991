# Horizon Bank — Bank Account System Capstone

A complete Python/FastAPI implementation of the supplied Horizon Bank capstone specification. The case study permits Spring Boot, Node.js or Python and focuses on PostgreSQL 16, Redis 7, Apache Kafka 4.3, transactions, locking, caching and events.

## Stack
- Python 3.12 + FastAPI
- PostgreSQL 16 — system of record
- Redis 7 — cache + idempotency
- Apache Kafka 4.3.1 — events
- Kafka UI — visual verification
- Docker Compose

## Project structure

```text
bank-account-system-capstone/
├── app/
│   ├── main.py
│   ├── consumer.py
│   ├── config.py
│   ├── db.py
│   ├── cache.py
│   ├── events.py
│   ├── errors.py
│   └── schemas.py
├── db/01_schema.sql
├── db/02_seed.sql
├── sql/01_open_account.sql
├── sql/02_transfer.sql
├── sql/03_statement.sql
├── sql/04_reconciliation.sql
├── sql/05_constraints_say_no.sql
├── sql/06_consumer_idempotency.sql
├── kafka/create-topics.sh
├── scripts/create-topics.sh
├── scripts/concurrency_test.sh
├── postman_collection.json
├── TEST_EVIDENCE.md
├── docs/DEMO_AND_VIVA.md
├── Dockerfile
├── docker-compose.yml
└── requirements.txt
```

## 1. Start everything

```bash
git clone <your-repository-url>
cd bank-account-system-capstone
cp .env.example .env
docker compose up -d --build
```

Wait until PostgreSQL, Redis and Kafka are healthy:

```bash
docker compose ps
```

The API is `http://localhost:8080`; Kafka UI is `http://localhost:8085`.

The database initialization scripts run only on the first PostgreSQL volume creation. To reset to the clean seed:

```bash
docker compose down -v
docker compose up -d --build
```

## 2. Verify seeded accounts

```bash
docker exec -it bank-postgres psql -U bank_app -d bankdb -c "SELECT a.account_number,c.full_name,a.account_type,a.balance,a.status FROM account a JOIN customer c USING(customer_id) ORDER BY a.account_number;"
```

The supplied case study expects these five seed accounts: ...001 Priya SAVINGS ₹55,000; ...002 Rahul SAVINGS ₹28,500; ...003 Rahul CURRENT ₹88,000; ...004 Ananya SAVINGS ₹13,500; ...005 Ananya CURRENT ₹5,000 FROZEN.

## 3. Create Kafka topics

```bash
./scripts/create-topics.sh
```

The API/consumer can also auto-create topics if broker auto-creation is enabled, but explicit topic creation is recommended for the demo.

## 4. API examples

### Open an account

```bash
curl -i -X POST http://localhost:8080/api/v1/accounts \
  -H 'Content-Type: application/json' \
  -d '{"customer":{"fullName":"Karthik Rao","email":"karthik.rao@example.com","phone":"9876500004","dateOfBirth":"1995-02-14","pan":"CKRPR7788Q"},"accountType":"SAVINGS","initialDeposit":"15000.00"}'
```

### Account enquiry — cache miss/hit

```bash
curl -i http://localhost:8080/api/v1/accounts/501000000001
curl -i http://localhost:8080/api/v1/accounts/501000000001
```

Expect `X-Cache: MISS` then `X-Cache: HIT`.

### Transfer

```bash
curl -i -X POST http://localhost:8080/api/v1/transfers \
  -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: demo-001' \
  -d '{"fromAccountNumber":"501000000001","toAccountNumber":"501000000002","amount":"2500.00","remarks":"Rent October"}'
```

Send the exact same request again. It must return the original response with `Idempotent-Replayed: true` and must not move money again.

### Statement

```bash
curl -i 'http://localhost:8080/api/v1/accounts/501000000001/statement?fromDate=2026-09-01&toDate=2026-09-30&page=0&size=3'
```

### Health

```bash
curl http://localhost:8080/health
```

## 5. SQL labs

```bash
docker exec bank-postgres psql -U bank_app -d bankdb -f /sql/02_transfer.sql
docker exec bank-postgres psql -U bank_app -d bankdb -f /sql/03_statement.sql
docker exec bank-postgres psql -U bank_app -d bankdb -f /sql/04_reconciliation.sql
```

`04_reconciliation.sql` is the important integrity proof. R1–R3 should return zero rows.

## 6. Redis verification

```bash
docker exec -it bank-redis redis-cli HGETALL bank:account:501000000001
docker exec -it bank-redis redis-cli TTL bank:account:501000000001
docker exec -it bank-redis redis-cli GET bank:idem:demo-001
```

## 7. Kafka verification

Open Kafka UI at `http://localhost:8085`, then inspect:
- `bank.account.opened.v1`
- `bank.transfer.completed.v1`
- `bank.transfer.failed.v1`

The notification service consumes these events and writes `notification_log` using `ON CONFLICT DO NOTHING` so replay is idempotent.

## 8. Concurrency test

Run after resetting the stack and before using up the seed account for unrelated tests:

```bash
./scripts/concurrency_test.sh
```

The supplied test catalogue expects 20 parallel ₹1,000 transfers from account ...004 with ₹13,500 starting balance: 13 should complete and 7 should be rejected for insufficient funds.

## 9. Postman

Import `postman_collection.json` into Postman. It includes account opening, cache MISS/HIT, transfer, replay, statement, negative transfer cases and health.

## 10. Design decisions

1. PostgreSQL is the only system of record.
2. Transfer uses one DB transaction: lock both accounts in ascending `account_id`, validate, insert transfer, update both balances, insert two ledger rows, commit.
3. Redis and Kafka are never called inside the money transaction.
4. Account cache uses cache-aside with 600-second TTL.
5. Statement pages use versioned keys with 300-second TTL.
6. Idempotency uses Redis `SET NX EX` plus the PostgreSQL unique constraint.
7. Kafka events are published after commit.
8. The notification consumer is idempotent via the composite primary key `(event_id, account_number)`.

## Important note about the supplied repository

The original GitHub URL was provided with the case study, but the environment used to prepare this package could not fetch that repository directly. This implementation is therefore prepared from the uploaded official case-study PDF, including its API contract, data model, acceptance criteria, architecture and Python stack guidance. It is not claimed to be a byte-for-byte copy of the GitHub starter kit.

## Submission checklist

- [ ] Source code committed
- [ ] SQL schema + seed committed
- [ ] Docker Compose works from a clean volume
- [ ] Postman collection imported and run
- [ ] Reconciliation R1–R3 = zero rows
- [ ] Cache MISS/HIT demonstrated
- [ ] Idempotent replay demonstrated
- [ ] Kafka event + notification log demonstrated
- [ ] Concurrency test output saved
- [ ] `TEST_EVIDENCE.md` completed with screenshots/outputs
- [ ] 10-minute demo rehearsed
