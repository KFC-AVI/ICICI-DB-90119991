#!/bin/sh
set -eu
BROKER="${1:-localhost:9092}"
for topic in bank.account.opened.v1 bank.transfer.completed.v1 bank.transfer.failed.v1; do
  kafka-topics.sh --bootstrap-server "$BROKER" --create --if-not-exists --topic "$topic" --partitions 3 --replication-factor 1
  kafka-configs.sh --bootstrap-server "$BROKER" --entity-type topics --entity-name "$topic" --alter --add-config retention.ms=604800000 >/dev/null || true
done
kafka-topics.sh --bootstrap-server "$BROKER" --list
