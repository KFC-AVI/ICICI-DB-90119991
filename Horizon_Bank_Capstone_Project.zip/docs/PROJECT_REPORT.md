# Horizon Bank Bank Account System — Project Report

## 1. Abstract

This project implements a small API-first bank account service for Horizon Bank. It supports account opening, account enquiry, internal fund transfer and paginated statements. PostgreSQL is the system of record, Redis provides cache-aside reads and idempotency state, and Apache Kafka publishes business events to an asynchronous notification service.

## 2. Objectives

- Open an account with an initial deposit.
- Transfer money atomically between Horizon accounts.
- Keep balances and ledger entries strongly consistent under concurrency.
- Provide fast cached account and statement reads.
- Prevent duplicate transfers when clients retry.
- Publish account/transfer events without putting notification work inside the transfer transaction.
- Demonstrate reconciliation and concurrency evidence.

## 3. Architecture

```text
Postman / curl
      |
      v
FastAPI bank-account-service
  |       |        |
  |       |        +--> Kafka --> notification-service --> notification_log
  |       +--> Redis
  v
PostgreSQL
  customer
  account
  fund_transfer
  account_transaction
  notification_log
```

## 4. Database design

Five core tables are used. `customer` is identified by PAN; `account` stores the current balance; `fund_transfer` stores the business transfer; `account_transaction` is the append-only ledger; and `notification_log` records idempotently processed notifications.

Important controls include unique PAN/email/phone constraints, one SAVINGS and one CURRENT account per customer, INR-only accounts, non-negative balances, transfer amount limits, distinct sender/receiver accounts, unique idempotency keys and exactly one debit/credit ledger leg per transfer.

## 5. Transfer transaction

The critical money path is:

1. Validate the request.
2. Claim the idempotency key in Redis when available.
3. Begin one PostgreSQL transaction.
4. Lock both accounts with `SELECT ... FOR UPDATE` in ascending `account_id` order.
5. Check ACTIVE status, available funds and the IST daily limit.
6. Insert the transfer row.
7. Debit the sender and credit the receiver using SQL arithmetic.
8. Insert exactly two ledger rows.
9. Commit.
10. Invalidate account cache and increment statement versions.
11. Store the completed idempotency response.
12. Publish `TransferCompleted` after commit.

No Redis or Kafka network call is made while the database rows are locked.

## 6. Redis

Account summaries use `bank:account:{accountNumber}` with a 600-second TTL. Statement pages use versioned keys with a 300-second TTL. Idempotency uses `bank:idem:{key}` for 24 hours. Cache invalidation happens only after a successful database commit.

## 7. Kafka

Topics:
- `bank.account.opened.v1`
- `bank.transfer.completed.v1`
- `bank.transfer.failed.v1` (stretch)

The transfer event uses the sender account number as the Kafka key. The notification consumer uses `(event_id, account_number)` as its primary key and `ON CONFLICT DO NOTHING`, making repeated event delivery harmless.

## 8. API

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/accounts` | Open account |
| GET | `/api/v1/accounts/{accountNumber}` | Account enquiry |
| POST | `/api/v1/transfers` | Fund transfer |
| GET | `/api/v1/transfers/{referenceNo}` | Transfer enquiry |
| GET | `/api/v1/accounts/{accountNumber}/statement` | Statement |
| GET | `/health` | Health |

## 9. Testing

The supplied case study defines functional tests TC-01–TC-30. The implementation includes a Postman collection, reconciliation SQL and a 20-request concurrency script. The final submission should contain actual execution outputs and screenshots in `TEST_EVIDENCE.md`.

## 10. Limitations / stretch improvements

The supplied specification identifies an outbox table as a stretch improvement for the small crash window between database commit and Kafka publish. Authentication/authorization, external-bank transfers, KYC uploads, interest, fees, cards and multi-currency support are outside Phase 1.
