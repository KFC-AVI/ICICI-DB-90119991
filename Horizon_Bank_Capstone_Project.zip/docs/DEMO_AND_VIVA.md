# 10-Minute Demo + Viva Notes

## Demo order
1. Show architecture: FastAPI → PostgreSQL, Redis, Kafka → notification-service.
2. Show `docker compose ps` and Kafka UI on `http://localhost:8085`.
3. Show `POST /accounts` and the new account + initial ledger row.
4. GET the same account twice: explain `X-Cache: MISS` then `HIT`.
5. POST a transfer with `Idempotency-Key`.
6. Repeat the same request: show `Idempotent-Replayed: true` and unchanged balance.
7. Show PostgreSQL transfer row + exactly two ledger legs.
8. Show Kafka `bank.transfer.completed.v1` event and notification_log.
9. Show statement with paging and opening/closing balances.
10. Run reconciliation and concurrency test; explain why row locks prevent lost updates.

## Viva one-liners
- **Why PostgreSQL?** It is the system of record and gives ACID transactions, constraints and row-level locking.
- **Why Redis?** It accelerates display reads and stores short-lived idempotency state; it is never the source of truth.
- **Why Kafka?** It decouples downstream notifications from the transfer request.
- **Why `NUMERIC(15,2)`?** Money needs exact decimal arithmetic; float/double can introduce rounding errors.
- **Why `FOR UPDATE`?** It serializes concurrent changes to the same account rows.
- **Why lock in ascending account_id order?** It prevents circular wait/deadlocks for A→B and B→A transfers.
- **Why validate after locking?** A balance read before the lock may already be stale.
- **Why cache-aside?** PostgreSQL remains authoritative; cache misses simply read and repopulate from the DB.
- **Why invalidate after commit?** Invalidating before commit allows a concurrent read to repopulate stale data.
- **Why idempotency?** A client can retry after a timeout; the same logical transfer must not move money twice.
- **Why a DB unique constraint too?** Redis can be lost or unavailable, so PostgreSQL is the final safety net.
- **Why publish after commit?** Otherwise Kafka could announce a transfer that later rolls back.
- **What is the known Kafka gap?** A crash between DB commit and publish can lose the event; the case study lists an outbox as stretch improvement.
- **Why append-only ledger?** It gives an audit trail for every balance movement and supports reconciliation.
- **Why no UI?** The case study says UI is optional and earns no marks; Postman/curl is sufficient.
