\set acc '501000000001'
\set from_ts '2026-09-01 00:00:00+05:30'
\set to_ts '2026-10-01 00:00:00+05:30'
\set size 3
\set page 0
SELECT account_id AS acc_id FROM account WHERE account_number=:'acc' \gset
SELECT t.txn_id,to_char(t.txn_time,'YYYY-MM-DD HH24:MI') txn_time,t.txn_type,t.amount,t.balance_after,t.description,ft.reference_no
FROM account_transaction t LEFT JOIN fund_transfer ft ON ft.transfer_id=t.transfer_id
WHERE t.account_id=:acc_id AND t.txn_time>=:'from_ts' AND t.txn_time<:'to_ts'
ORDER BY t.txn_time DESC,t.txn_id DESC LIMIT :size OFFSET (:page*:size);
SELECT count(*) total_elements,ceil(count(*)::numeric/:size) total_pages,
COALESCE(sum(amount) FILTER(WHERE txn_type='CREDIT'),0) total_credits,
COALESCE(sum(amount) FILTER(WHERE txn_type='DEBIT'),0) total_debits
FROM account_transaction WHERE account_id=:acc_id AND txn_time>=:'from_ts' AND txn_time<:'to_ts';
SELECT COALESCE((SELECT balance_after FROM account_transaction WHERE account_id=:acc_id AND txn_time<:'from_ts' ORDER BY txn_time DESC,txn_id DESC LIMIT 1),0) opening_balance,
COALESCE((SELECT balance_after FROM account_transaction WHERE account_id=:acc_id AND txn_time<:'to_ts' ORDER BY txn_time DESC,txn_id DESC LIMIT 1),0) closing_balance;
