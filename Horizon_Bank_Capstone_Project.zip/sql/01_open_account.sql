BEGIN;
INSERT INTO customer(full_name,email,phone,date_of_birth,pan)
VALUES('Lab User','lab.user@example.com','9876500099','1990-01-01','LABUS1234Q')
ON CONFLICT (pan) DO NOTHING;
INSERT INTO account(customer_id,account_type,balance)
SELECT customer_id,'SAVINGS',15000.00 FROM customer WHERE pan='LABUS1234Q'
ON CONFLICT DO NOTHING;
INSERT INTO account_transaction(account_id,txn_type,amount,balance_after,description)
SELECT account_id,'CREDIT',15000.00,balance,'Initial deposit' FROM account
WHERE customer_id=(SELECT customer_id FROM customer WHERE pan='LABUS1234Q')
AND account_type='SAVINGS'
AND NOT EXISTS(SELECT 1 FROM account_transaction t WHERE t.account_id=account.account_id AND t.transfer_id IS NULL);
COMMIT;
