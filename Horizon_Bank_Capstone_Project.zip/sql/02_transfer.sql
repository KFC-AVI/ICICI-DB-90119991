BEGIN;
SET LOCAL lock_timeout='3s';
SELECT account_id,account_number,balance,status
FROM account WHERE account_number IN ('501000000001','501000000002')
ORDER BY account_id FOR UPDATE;
SELECT COALESCE(SUM(amount),0) AS sent_today
FROM fund_transfer WHERE from_account_id=(SELECT account_id FROM account WHERE account_number='501000000001')
AND status='COMPLETED' AND created_at >= date_trunc('day',now() AT TIME ZONE 'Asia/Kolkata') AT TIME ZONE 'Asia/Kolkata';
INSERT INTO fund_transfer(idempotency_key,from_account_id,to_account_id,amount,remarks)
VALUES('lab-transfer-0001',(SELECT account_id FROM account WHERE account_number='501000000001'),(SELECT account_id FROM account WHERE account_number='501000000002'),2500.00,'Rent October')
RETURNING transfer_id,reference_no \gset
UPDATE account SET balance=balance-2500.00,updated_at=now() WHERE account_number='501000000001' RETURNING balance AS from_balance \gset
UPDATE account SET balance=balance+2500.00,updated_at=now() WHERE account_number='501000000002' RETURNING balance AS to_balance \gset
INSERT INTO account_transaction(account_id,transfer_id,txn_type,amount,balance_after,description)
VALUES((SELECT account_id FROM account WHERE account_number='501000000001'),:'transfer_id','DEBIT',2500.00,:from_balance,'Transfer to 501000000002 - Rent October'),
((SELECT account_id FROM account WHERE account_number='501000000002'),:'transfer_id','CREDIT',2500.00,:to_balance,'Transfer from 501000000001 - Rent October');
COMMIT;
