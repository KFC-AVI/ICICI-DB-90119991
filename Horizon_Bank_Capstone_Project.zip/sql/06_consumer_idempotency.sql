\set event_id '0b6f7a52-3c1e-4d0a-9a51-2f8e6c1d9b47'
INSERT INTO notification_log(event_id,account_number,event_type,message)
VALUES(:'event_id','501000000001','TransferCompleted','debit alert'),(:'event_id','501000000002','TransferCompleted','credit alert')
ON CONFLICT(event_id,account_number) DO NOTHING;
INSERT INTO notification_log(event_id,account_number,event_type,message)
VALUES(:'event_id','501000000001','TransferCompleted','duplicate'),(:'event_id','501000000002','TransferCompleted','duplicate')
ON CONFLICT(event_id,account_number) DO NOTHING;
SELECT account_number,message FROM notification_log WHERE event_id=:'event_id' ORDER BY account_number;
