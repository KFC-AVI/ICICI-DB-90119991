-- R1: current balance must equal the latest ledger balance_after.
SELECT a.account_number, a.balance, COALESCE(latest.balance_after,0) AS ledger_balance
FROM account a
LEFT JOIN LATERAL (
  SELECT balance_after FROM account_transaction t
  WHERE t.account_id=a.account_id ORDER BY txn_time DESC,txn_id DESC LIMIT 1
) latest ON TRUE
WHERE a.balance <> COALESCE(latest.balance_after,0);

-- R2: every completed transfer has exactly one debit and one credit.
SELECT ft.reference_no, ft.transfer_id, COUNT(t.txn_id) AS ledger_legs
FROM fund_transfer ft LEFT JOIN account_transaction t ON t.transfer_id=ft.transfer_id
WHERE ft.status='COMPLETED'
GROUP BY ft.reference_no,ft.transfer_id
HAVING COUNT(t.txn_id) <> 2;

-- R3: ledger legs point to the correct accounts and amounts.
SELECT ft.reference_no, ft.amount, d.amount AS debit_amount, c.amount AS credit_amount,
       a_from.account_number AS debit_account, a_to.account_number AS credit_account
FROM fund_transfer ft
JOIN account a_from ON a_from.account_id=ft.from_account_id
JOIN account a_to ON a_to.account_id=ft.to_account_id
LEFT JOIN account_transaction d ON d.transfer_id=ft.transfer_id AND d.txn_type='DEBIT'
LEFT JOIN account_transaction c ON c.transfer_id=ft.transfer_id AND c.txn_type='CREDIT'
WHERE ft.status='COMPLETED'
  AND (d.account_id IS DISTINCT FROM ft.from_account_id
       OR c.account_id IS DISTINCT FROM ft.to_account_id
       OR d.amount IS DISTINCT FROM ft.amount
       OR c.amount IS DISTINCT FROM ft.amount);
