-- Run individually or without ON_ERROR_STOP to demonstrate DB defence-in-depth.
UPDATE account SET balance=balance-100000 WHERE account_number='501000000004';
INSERT INTO account(customer_id,account_type,balance) SELECT customer_id,'SAVINGS',1000 FROM customer WHERE pan='ABCPS1234K';
INSERT INTO fund_transfer(idempotency_key,from_account_id,to_account_id,amount) VALUES('lab-d1-4-0003',1,1,100);
INSERT INTO fund_transfer(idempotency_key,from_account_id,to_account_id,amount) VALUES('seed-0001',1,2,5000);
INSERT INTO customer(full_name,email,phone,date_of_birth,pan) VALUES('Test User','test.user@example.com','9876500099','1990-01-01','ABC123');
DELETE FROM account_transaction WHERE txn_id=1;
